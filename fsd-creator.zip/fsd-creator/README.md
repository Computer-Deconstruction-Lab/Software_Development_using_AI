# fsd-creator Skill

A Claude skill that generates structured Feature Specification Documents (FSDs) in Markdown format from a high-level project description.

## Trigger Keywords

Use any of the following to activate this skill in Claude:

- `createfsd`
- `newproject`
- `newrequirements`
- Or simply describe a new software project and ask for documentation/specs

## What It Does

1. **Interviews you** — Asks targeted questions about your project (platform, language, goals, interfaces, constraints, etc.)
2. **Generates an FSD** — Produces a complete Markdown specification document including:
   - Revision History
   - Project Overview
   - Functional Requirements (tagged `REQ-001`, `REQ-002`, ...)
   - Hardware & Platform Constraints
   - API & Interface Definitions
   - Test Plans (tagged `TEST-001`, `TEST-002`, ...)
   - Appendix (optional)
3. **Delivers a `.md` file** — Saves and presents the file for download
4. **Offers follow-ups** — Refine sections or export to `.docx`

## File Structure

```
fsd-creator/
├── README.md       ← This file
└── SKILL.md        ← The skill definition loaded by Claude
```

## Installation (Claude Skills)

Place this folder at:

```
/mnt/skills/user/fsd-creator/
```

Claude will automatically detect and use `SKILL.md` when the trigger keywords appear.

## Output Example

Generated files are named using the pattern:

```
[project-name]-fsd.md
```

e.g., `motor-controller-fsd.md`, `ble-sensor-node-fsd.md`

## Notes

- Designed with embedded/firmware projects in mind (C, C++, MCUs, RTOS) but works for any software project
- Requirements use formal "shall" / "should" language for traceability
- Every test cross-references at least one requirement
